﻿var categories = {
"mastercategories":[
{
    "index": 0,
    "description": "OBDX REST APIs use HTTP verbs and a RESTful endpoint structure. Request and response payloads are formatted as JSON.\n\nOBDX REST API can be accessed using the following URL format\n\nhttps://host-name:port /digx/{version}/{resource}/{resource-specific-parameters}\n-	Host name is the domain.\n-	The version represents the supported version of the API. \n-	The resource represents one of the OBDX REST resources. \n-	The resource-specific part of the URL specifies the actual resource being referenced.\n\nA complete REST operation is formed by combining an HTTP method with the full URI to the resource you’re addressing. \n\nPOST https://ofss310841.in.oracle.com:7777/digx/v1/submissions\n\nTo create a complete request, combine the operation with the appropriate HTTP headers and any required JSON payload.\n\nThe service response includes a status code and wherever applicable a response body with the details of the response in JSON format.",
    "name": "Overview"
},
	{
    "index": 1,
    "description": "HTTP requests to the OBDX REST APIs are protected.Security in OBDX Platform is externalized and the bank has the option to implement the same as \n\t- Oracle IDM Suite\n\t- Open Source Equivalent.\n\nIn the case of Oracle IDM Suite is deployed for security, the OAM (Oracle Access Manager) creates the following cookies after a successful logon validation with OID.\n\t- JSESSIONID\n\t- OAMAuthnCookie_<HOSTNAME>:<PORT>\n\t- OAMAuthnHintCookie",
    "name": "Authentication"
},
{
    "index": 2,
    "description": "Origination APIs contain resource collections for originating a new account for multiple product types. \n\nThe product types supported are:\n•	Deposits (Savings and Current)\n•	Term Deposits\n•	Credit Cards\n•	Unsecured Personal Loans\n•	Secured Personal Loans (Auto Loans)\n\nThe resources and related sub resources under originations provide comprehensive workflows based on the product types and their associated configurations. The resources include view and compare offers, application forms, applicant details, address details, employment profile, financial profile, credit assessment information, documents and collaterals. Based on the product in which the account is being originated, it also has certain additional resources like insurance details in case of originating a loan or add-on card details in case of a credit card.\n\nThe application tracker resource allows for tracking the status of your application(s) across the origination phases. It allows updates to the application as applicable through the application tracker stages.",
    "name": "Originations"
},
{
    "index": 3,
    "description": "Allow you to perform servicing operations for your demand deposit accounts. It provides all operations on the debit cards issued for your account, cheque management operations like cheque book issue, stop/unblock cheque(s), inquire the status of your cheque(s). It has resources that fetch transaction history of the specified demand deposit account using multiple search criteria as query parameters.",
    "name": "Demand Deposits "
},
{
    "index": 4,
    "description": "Allows you to perform servicing operations for your term deposit accounts. It provides for opening of a new term deposit, modifying the maturity instructions of a deposit, inquire about term deposit details, perform top-ups to an existing term deposit, part or full redeem your existing term deposit. It has resources that fetch the transaction history of the specified term deposit account using multiple search criteria as query parameters.",
    "name": "Term Deposits "
},
{
    "index": 5,
    "description": "Allows you to perform servicing operations for your loan accounts. It provides for inquiring the details of a loan account, fetching the schedule of the specified loan account, making repayment or settling your loan account. It has resources that fetch the transaction history of the specified loan account using multiple search criteria as query parameters.",
    "name": "Loans "
},
{
    "index": 6,
    "description": "Allows you to perform servicing operations on your credit cards. It provides for inquiry of card details, card payments, manage limits, add-on card request, new PIN request, block card, replacement card, auto payment instruction, card cancellation. It has resources that fetch the transaction history of the specified credit card for the unbilled or billed periods.",
    "name": "Credit Cards "
},
{
    "index": 7,
    "description": "Payments APIs contain resource collections for performing all types of payment transactions. They allow you to setup multiple payees for your party id. For each payee you can setup multiple payment types having a unique nickname. Any payee setup or payment transaction type setup mandates an authentication API too, wherein an OTP (One Time Password) is sent to the email id and/or mobile number of the user. After the successful validation of the OTP is the payee or payment type for the payee enabled in the system.\n\nOnce the payees and transaction types within the payees are setup you can execute multiple payment APIs to carry out the actual payment transactions. The actual payment transaction also mandates an authentication API, wherein an OTP (One Time Password) is sent to the email id or mobile number of the user. Only after the successful validation of the OTP is the payment sent to the core banking payment product processor to complete the payment.",
    "name": "Payments"
},
{
    "index": 8,
    "description": "Wallet APIs allow for the entire wallets life cycle right from wallet registration, funding the wallet, request funds, pay from wallet, wallet transaction activity. ",
    "name": "Wallets"
},
{
    "index": 9,
    "description": "Allow you to fetch detailed information for a specified party id. You can also fetch all the accounts belonging to a specified party id.",
    "name": "Calculators"
},
{
    "index": 10,
    "description": "Parties REST APIs allow you to fetch detailed information for a specified party id. One can also get all the accounts belonging to a specified party id.",
    "name": "Parties"
},
{
    "index": 11,
    "description": "Allows you to setup various alert templates for all the transactions/events. Once the alert templates are setup they can be subscribed for the party ids",
    "name": "Alerts"
},
{
    "index": 12,
    "description": "Allow you to configure and manage access policies, entitlements, resources, roles and users. You can also setup and configure account access for a party id and their respective users.",
    "name": "Authorization "
},
{
    "index": 13,
    "description": "Allow you to configure and manage transaction limits for user roles.",
    "name": "Limits "
},
{
    "index": 14,
    "description": "Enumerations APIs allow for 'list of values' that are used across the application both for originations and servicing.",
    "name": "Enumerations"
},
{
    "index": 15,
    "description": "Allow allow you to fetch certain global information like events, locations, service requests.",
    "name": "Global"
},
{
    "index": 16,
    "description": "Allow you to configure and manage approval workflow(s) for transactions for users or user groups based on the rules configured.",
    "name": "Approvals"
},
{
    "index": 17,
    "description": "Allow you to setup and configure file upload templates, link them to users, upload files and also inquire status of the files processed at a file and record level.",
    "name": "File Uploads"
},
{
    "index": 18,
    "description": "Allow you to setup your financial goals. Allow you to quickly and easily set up specific savings target. It allows to plan the goal, by establishing the budget, initial contribution amount if any, and also the timeline for achieving it and hence concluding on the amount to be invested in monthly, weekly or quarterly format. Customer then chooses the start date, the funding account and also how the final amount, is going to be credited or given back to the goal creator.",
    "name": "Goals"
},
{
	"index":19,
	"description":"Allow you to set up categories and sub categories for clubbing similar ended debit transactions. All debited transactions,get categorized as per set rules running on transaction descriptions. Further a user can create, modify new and existing categories and would be able to view them as per the changes made. Also transactions can be split to multiple smaller transactions and recategorized. Allow you to do a category wise comparison of expenses, to know trends and insights on spending patterns.",
	"name":"Spend Analysis"
},
{
	"index":20,
	"description":"Allow you to set, manage and delete budget of the categories set in spend. It is available on a   monthly rotation basis.",
	"name":"Budget"
},
{
	"index":21,
	"description":"Allows you to set, manage and delete nickname for your accounts including current or savings accounts, term deposits, loans or credit cards. Nickname is a name that you can give to your account so that the account can be used easily. After providing the nickname, the system will display nickname alongside the account number so that you need not remember the account number while doing various transactions.",
	"name":"Account Nickname"
},
{
	"index":22,
	"description":"Allows you to define a working window for a financial transaction (typically applicable to payments). Working window is a time duration of the day during which the transaction is available for processing. If you perform a transaction when working window is open then the system will process the transaction normally. However if you perform a transaction when working window is closed then the system might reject the transaction or it might post the transaction with next value date depending on the option selected while creatin the working window. A working window once creation for a transaction will remain applicable from its start date till the time it is deleted or updated or a new window is created overriding the earlier one. Exceptions can be created to a working window to handle difference timings for transaction processing on specific days.",
	"name":"Working Window"
},
{
	"index":23,
	"description":"Allows you to define blackout for a transaction. Blackout is a period during which the transaction will not be available to the users. If user performs a transaction during its blackout period then the system will give error indicating that the transaction is currently not available. A blackout is defined from a start date and an end date. The blackout can have a time interval that repeats daily, in which case the transaction is blacked out daily for that time interval. Alternatively, blackout can be defined as Full blackout. In this case the blackout is applied completely from given time of start date till given time of the end date.",
	"name":"Transaction Blackout"
},

{
	"index":24,
	"description":"Reports are an integral part of actively managing any company. Management uses the reports to track progress toward its various goals, control expenditures, increase revenue, track fraudulent transactions if any. Processing timely data and the proper reporting and analytic capabilities enhances the ability to make more informed, evidence-based decisions.",
	"name":"Reports"
}
]
};
var subCategories = {
"list":[
	{
    "index": 1,
    "yaml": "Originations_Application Form - Generic.yaml",
    "description": "Allows for the various offers available for chosen product group in which the account is to be originated. It allows capture of all the basic details related to the application followed by submission. It provides fetching of already created submissions on the basis of submission ID, providing document check-list for the submission and finally sending the submission details to the core system. \n\nIt supports canceling a submission if a user is not interested anymore and listing all the submissions that the user has initiated and are in progress.",
    "parentcategory": "Originations",
    "displayName": "Application Form - Generic"
},
{
    "index": 2,
    "yaml": "Originations_Application Form - Demand Deposits.yaml",
    "description": "Allows for capture of demand deposit account specific details in the application for e.g. debit card required, delivery method for the debit card.",
    "parentcategory": "Originations",
    "displayName": "Application Form - Demand Deposits"
},
{
    "index": 3,
    "yaml": "Originations_Application Form - Term Deposits.yaml",
    "description": "Allows for capture of term deposit account specific details in the application for e.g. deposit tenure, amount for which term deposit is being originated.",
    "parentcategory": "Originations",
    "displayName": "Application Form - Term Deposits"
},
{
    "index": 4,
    "yaml": "Originations_Application Form - Loans.yaml",
    "description": "Allows for loan account specific details in the application for e.g. loan tenure, amount of loan required, purpose of loan, credit assessment related data.",
    "parentcategory": "Originations",
    "displayName": "Application Form - Loans"
},
{
    "index": 5,
    "yaml": "Originations_Application Form - Credit Cards.yaml",
    "description": "Allows for credit card specific details in the application for e.g. add-on card required, name of the add-on card, card delivery options, statement delivery options, card limits.",
    "parentcategory": "Originations",
    "displayName": "Application Form - Credit Cards"
},
{
    "index": 6,
    "yaml": "Originations_Applicants.yaml",
    "description": "Allows for capture of basic personal information for the applicant(s).",
    "parentcategory": "Originations",
    "displayName": "Applicants "
},
{
    "index": 7,
    "yaml": "Originations_Addresses.yaml",
    "description": "The addresses sub-resource allows for capture of address details, fetch addresses, modify addresses, delete addresses for the applicant(s) of the application.",
    "parentcategory": "Originations",
    "displayName": "Addresses"
},
{
    "index": 8,
    "yaml": "Originations_Contact Points.yaml",
    "description": "The contact points sub-resource allows for capture of contact points like telephone numbers, email id, contact preferences for the applicant(s) of the application.",
    "parentcategory": "Originations",
    "displayName": "Contact Points"
},
{
    "index": 10,
    "yaml": "Originations_Employments.yaml",
    "description": "The employments sub-resource allows for capture of employment details, fetch employment details, modify employment details, delete employment details for the applicant(s) of the application.",
    "parentcategory": "Originations",
    "displayName": "Employments"
},
{
    "index": 11,
    "yaml": "Originations_Financial Profile.yaml",
    "description": "The financial profile sub-resource allows for capture of income, expense, assets and liabilities for the applicant(s) of the application. It also allows you to fetch details of the income, expense, assets or liabilities given the respective identifier, modify them or perform delete operations.",
    "parentcategory": "Originations",
    "displayName": "Financial Profile"
},
{
    "index": 12,
    "yaml": "Originations_Credit Assessment.yaml",
    "description": "Allows you to get the credit risk assessment from the credit bureau as a summary.",
    "parentcategory": "Originations",
    "displayName": "Credit Assessment"
},
{
    "index": 13,
    "yaml": "Originations_Application Tracker.yaml",
    "description": "Provides operations to track the submitted application as it moves through the various stages of the originations lifecycle. It allows you to complete a previously saved application, cancel an application, negotiate with the bank for certain attributes based on the account type being originated and ability to specify applicable additional preferences.",
    "parentcategory": "Originations",
    "displayName": "Application Tracker"
},
{
    "index": 14,
    "yaml": "Originations_Consents.yaml",
    "description": "Allows you to create, update or view consents related to marketing information.",
    "parentcategory": "Originations",
    "displayName": "Consents"
},
{
    "index": 15,
    "yaml": "Originations_Collaboration.yaml",
    "description": "The collaboration resource allows for creating a collaboration, fetching all collaborations, deleting a specific collaboration.",
    "parentcategory": "Originations",
    "displayName": "Collaboration"
},
{
    "index": 16,
    "yaml": "Originations_Collaterals.yaml",
    "description": "The collaterals sub-resource allows for capture of vehicle collateral details, ownership details in the case of a secure personal loan application.",
    "parentcategory": "Originations",
    "displayName": "Collaterals"
},
{
    "index": 17,
    "yaml": "Originations_Content.yaml",
    "description": "Allows you to create, update or view document checklist and documents related to age proof, address proof, as defined by the document checklist for the type of account being originated",
    "parentcategory": "Originations",
    "displayName": "Content"
},
{
    "index": 18,
    "yaml": "Global_Global.yaml",
    "description": "Allow you to fetch certain information that is applicable globally across the application.",
    "parentcategory": "Global",
    "displayName": "Global"
},
{
    "index": 1,
    "yaml": "Payments_Payees.yaml",
    "description": "Allow you to setup multiple payees as payee groups for a party id. Each payee group can then have multiple payment types for the payee. \n\nThe following payment types are supported:\n\t-	Internal Transfer (Payee Account within the same bank) \n\t-	Domestic Transfer (Payee Account in another bank in the same country) \n\t\t\to\tSEPA, UK & India Domestic Payments are supported under domestic \n\t-	International Transfer (Payee Account in another bank in another country) \n\t-	Email ID/Mobile No (Payee specified using email id or mobile no) \n\t-	Domestic Draft (Draft Issued that is payable in the same country) \n\t-	International Draft (Draft Issued that is payable in another country) \n\nOnce the payees and the payment transaction types are setup, APIs allow you to fetch, modify or delete any of the payee groups or the payment transaction types within the payee groups.",
    "parentcategory": "Payments",
    "displayName": "Payees"
},
{
    "index": 7,
    "yaml": "Payments_Internal Transfers.yaml",
    "description": "Allow you to perform funds transfer to a payee account within the same bank. ",
    "parentcategory": "Payments",
    "displayName": "Internal Transfers"
},
{
    "index": 8,
    "yaml": "Payments_Domestic Transfers.yaml",
    "description": "Allow you to perform funds transfer to a payee account in another bank in the same country. ",
    "parentcategory": "Payments",
    "displayName": "Domestic Transfers"
},
{
    "index": 9,
    "yaml": "Payments_International Transfers.yaml",
    "description": "Allow you to perform funds transfer to a payee account in another bank in another country.",
    "parentcategory": "Payments",
    "displayName": "International Transfers"
},
{
    "index": 10,
    "yaml": "Payments_Peer to Peer Transfers.yaml",
    "description": "Allow you to perform funds transfer to either an email id or mobile number. It also has the APIs to Claim Money by the Payee who has received the money from it’s peer.",
    "parentcategory": "Payments",
    "displayName": "Peer to Peer Transfers"
},
{
    "index": 11,
    "yaml": "Payments_Self Transfers.yaml",
    "description": "Allow you to perform funds transfer within your own accounts within the same bank. ",
    "parentcategory": "Payments",
    "displayName": "Self Transfers"
},
{
    "index": 12,
    "yaml": "Payments_Adhoc Transfers.yaml",
    "description": "Allow you to initiate adhoc funds transfer to a payee account without maintaining payee account details. \n The following payment types are supported: \n\t- Internal Transfer \n\t- Domestic Transfer \n\t- International Transfer",
    "parentcategory": "Payments",
    "displayName": "Adhoc Transfers"
},
{
    "index": 13,
    "yaml": "Payments_Merchant Payments.yaml",
    "description": "Allow you to setup and maintain merchants. They also support merchant payment APIs.",
    "parentcategory": "Payments",
    "displayName": "Merchant Payments"
},
{
    "index": 14,
    "yaml": "Payments_Domestic Draft Issuance.yaml",
    "description": "Allow you to issue domestic draft favoring a payee in the same country. ",
    "parentcategory": "Payments",
    "displayName": "Domestic Draft Issuance"
},
{
    "index": 15,
    "yaml": "Payments_International Draft Issuance.yaml",
    "description": "Allow you to issue international draft favoring a payee in another same country. ",
    "parentcategory": "Payments",
    "displayName": "International Draft Issuance"
},
{
    "index": 16,
    "yaml": "Payments_Future Dated Instructions.yaml",
    "description": "Allow you to setup future dated payment instructions to be executed once on a future date or recursively. One can setup the future dated recursive instructions ending on a particular future date or ending after a specified number of occurrences. \n\nThe following payment types are supported for future dated instructions: \n\t-	Self Transfer (Your own accounts within the same bank)\n\t-	Internal Transfer (Payee Account within the same bank) \n\t-	Domestic Transfer (Payee Account in another bank in the same country) \n\t-	International Transfer (Payee Account in another bank in another country) \n\t-	Domestic Draft (Draft Issued that is payable in the same country) \n\t-	International Draft (Draft Issued that is payable in another country) \n\nOnce the future dated instruction are setup, there are APIs that allow you to fetch, modify or delete any of the instructions",
    "parentcategory": "Payments",
    "displayName": "Future Dated  Instructions"
},
{
    "index": 21,
    "yaml": "Payments_Direct Debits.yaml",
    "description": "Allow you to setup direct debit mandates for a party id. Each direct debit group can have multiple direct debit setups. There are APIs that allow you to fetch, modify or delete any of the direct debits already setup.",
    "parentcategory": "Payments",
    "displayName": "Direct Debits"
},
{
    "index": 22,
    "yaml": "Payments_Direct Debit Instructions.yaml",
    "description": "Allow you to setup future dated direct debit instructions to be executed future dated only once or recursively. One can setup the future dated recursive instructions ending on a particular future date or ending after a specified number of occurrences.",
    "parentcategory": "Payments",
    "displayName": "Direct Debit Instructions"
},
{
    "index": 25,
    "yaml": "Payments_Bill Payments.yaml",
    "description": "Allow you to setup various biller categories, setup billers with the relevant relationship numbers for your party. Any biller setup for a party id mandates an authentication API too, wherein an OTP (One Time Password) is sent to the email id and/or mobile number of the user. Only after the successful validation of the OTP is the biller setup for that party id in the system.",
    "parentcategory": "Payments",
    "displayName": "Bill Payments"
},
{
    "index": 27,
    "yaml": "Payments_Credit Card Payments.yaml",
    "description": "Allow you to make payments to your credit cards",
    "parentcategory": "Payments",
    "displayName": "Credit Card Payments"
},
{
    "index": 28,
    "yaml": "Payments_Remittances.yaml",
    "description": "Allow you to fetch both the inward remittances received and outward remittances sent for your accounts. One can fetch the remittance details for a specified account or all accounts, one can also specify filter criteria based on date and amount ranges.",
    "parentcategory": "Payments",
    "displayName": "Remittances"
},
{
    "index": 29,
    "yaml": "Payments_Favourites.yaml",
    "description": "Allow you to mark a payment transaction as your Favorite. They also allow you fetch all favorite payments or delete particular payment that you longer want as a favorite.",
    "parentcategory": "Payments",
    "displayName": "Favorites"
},
{
    "index": 1,
    "yaml": "Demand Deposits_Inquiries.yaml",
    "description": "Allows you to fetch all the demand deposits for your party id, fetch all the details for the specified demand deposit account.",
    "parentcategory": "Demand Deposits ",
    "displayName": "Inquiries"
},
{
    "index": 2,
    "yaml": "Demand Deposits_Cheques.yaml",
    "description": "Allows you to perform various cheque operations. You can request for a cheque book with details of cheque leaves and other parameters, stop/unblock cheque(s) with various parameters, inquire the status of your cheque(s).",
    "parentcategory": "Demand Deposits ",
    "displayName": "Cheques"
},
{
    "index": 3,
    "yaml": "Demand Deposits_Debit Cards.yaml",
    "description": "Allow you to manage all the operations related to debit cards for your demand deposit account. You can apply for a debit card, replace a debit card, request for a PIN for your card, fetch all the debit cards issued for a specified account.",
    "parentcategory": "Demand Deposits ",
    "displayName": "Debit Cards"
},
{
    "index": 4,
    "yaml": "Demand Deposits_Statement.yaml",
    "description": "Allow you to fetch the transaction history of the specified demand deposit account using a variety of search criteria.\nThe various search criteria supported are:\n•	Last 'n' transactions\n•	Transactions of the previous month\n•	Transactions of the previous quarter\n•	Transactions for a specified period of from and to dates. \n•	Debit Only or Credit Only or Both types of transactions.\nIt also provides request for adhoc statement for a specified period or enrollment for e-statements.",
    "parentcategory": "Demand Deposits ",
    "displayName": "Statements"
},
{
    "index": 1,
    "yaml": "Term Deposits_Inquiries.yaml",
    "description": "Allow you to fetch all the term deposits for your party id, fetch all the details for the specified term deposit account.",
    "parentcategory": "Term Deposits ",
    "displayName": "Inquiries"
},
{
    "index": 2,
    "yaml": "Term Deposits_Transactions.yaml",
    "description": "Allow you to perform various operations on your term deposit account including opening of a new term deposit for the specified parameters, redeem a term deposit, top-up a term deposit.",
    "parentcategory": "Term Deposits ",
    "displayName": "Transactions"
},
{
    "index": 3,
    "yaml": "Term Deposits_Statements.yaml",
    "description": "Allow you to fetch the transaction history of the specified term deposit account using a variety of search criteria.\nThe various search criteria supported are:\n•	Last 'n' transactions\n•	Transactions of the previous month\n•	Transactions of the previous quarter\n•	Transactions for a specified period of from and to dates. ",
    "parentcategory": "Term Deposits ",
    "displayName": "Statements"
},
{
    "index": 4,
    "yaml": "Term Deposits_Lookups.yaml",
    "description": "Provide for the various enumerations used in term deposits accounts, for e.g. fetching all the term deposit products, various maturity instruction options.",
    "parentcategory": "Term Deposits ",
    "displayName": "Lookups"
},
{
    "index": 1,
    "yaml": "Loans_Inquiries.yaml",
    "description": "Allow you to fetch all the loan accounts for your party id, inquire all the details for the specified loan account, fetch the disbursement schedules in case of multiple disbursements, fetch the loan schedule and fetch the loan outstanding amounts.",
    "parentcategory": "Loans ",
    "displayName": "Inquiries"
},
{
    "index": 2,
    "yaml": "Loans_Transactions.yaml",
    "description": "Allow you to perform various operations on your loan account like repay a loan for the specified parameters or top-up a loan account.",
    "parentcategory": "Loans ",
    "displayName": "Transactions"
},
{
    "index": 3,
    "yaml": "Loans_Statements.yaml",
    "description": "Allow you to fetch the transaction history of the specified loan account using a variety of search criteria.\nThe various search criteria supported are:\n\t•	Last 'n' transactions\n\t•	Transactions of the previous month\n\t•	Transactions of the previous quarter\n\t•	Transactions for a specified period of from and to dates. ",
    "parentcategory": "Loans ",
    "displayName": "Statements"
},
{
    "index": 1,
    "yaml": "Credit Cards_Inquiries.yaml",
    "description": "Allow you to fetch all the credit cards for your party id, then inquire all the details for the specified credit card. You can also fetch the credit card status, repayment details, various limits and billing cycle of your credit card.",
    "parentcategory": "Credit Cards ",
    "displayName": "Inquiries"
},
{
    "index": 2,
    "yaml": "Credit Cards_Transactions.yaml",
    "description": "Allow you to perform various transactions and maintenances on your credit cards, you can update the card status, apply for a replacement card, update the billing cycle, update the card limits. One can also setup, modify or later delete auto repayment instructions for your credit card",
    "parentcategory": "Credit Cards ",
    "displayName": "Transactions"
},
{
    "index": 3,
    "yaml": "Credit Cards_Statements.yaml",
    "description": "Allow you to fetch the unbilled or billed transactions of the specified credit card. In the case of billed transaction history one can specify the month-year for which the transactions are to be fetched.",
    "parentcategory": "Credit Cards ",
    "displayName": "Statements"
},
{
    "index": 4,
    "yaml": "Credit Cards_Lookups.yaml",
    "description": "Provide for the various enumerations used in credit cards for e.g. card activation, deactivation, hot listing reasons, available billing cycles.",
    "parentcategory": "Credit Cards ",
    "displayName": "Lookups"
},
{
    "index": 1,
    "yaml": "Wallets_Registration.yaml",
    "description": "Allow you to open a new wallet. Any new wallet opening mandates an authentication API too, wherein an OTP (One Time Password) is generated and sent to the email id and/or mobile number of the user trying to open a wallet. Only after the successful verification of the OTP is the new wallet opened in the system.",
    "parentcategory": "Wallets",
    "displayName": "Registration"
},
{
    "index": 2,
    "yaml": "Wallets_Inquiries.yaml",
    "description": "Allow you to fetch details of a specified wallet like balance and other information.",
    "parentcategory": "Wallets",
    "displayName": "Inquiries"
},
{
    "index": 3,
    "yaml": "Wallets_Transactions.yaml",
    "description": "Allow you to perform various transactions on the wallet, one can add funds to the wallet, transfer funds to another wallet, request for funds from another wallet, accept or decline the fund request from another wallet.",
    "parentcategory": "Wallets",
    "displayName": "Transactions"
},
{
    "index": 4,
    "yaml": "Wallets_External Transfer.yaml",
    "description": "Allow you to fetch the transactions on your wallet. One can fetch the transactions using multiple search criteria.",
    "parentcategory": "Wallets",
    "displayName": "External Transfer"
},
{
    "index": 5,
    "yaml": "Wallets_Reports.yaml",
    "description": "Allow admin to fetch reports of users",
    "parentcategory": "Wallets",
    "displayName": "Reports"
},
{
    "index": 6,
    "yaml": "Wallets_Batch.yaml",
    "description": "Allow you to perform Wallet Batch related operations",
    "parentcategory": "Wallets",
    "displayName": "Batch"
},
{
    "index": 7,
    "yaml": "Wallets_Configurations.yaml",
    "description": "Allow operations related to configuration that can be performed only by admin",
    "parentcategory": "Wallets",
    "displayName": "Configurations"
},
{
    "index": 1,
    "yaml": "Calculators_Calculators.yaml",
    "description": "The calculators supported are: \n\t-	Loans Eligibility Calculator \n\t-	Loans Repayment Calculator \n\t-	Term Deposits Calculator \n\t-	Foreign Exchange Rates Calculator ",
    "parentcategory": "Calculators",
    "displayName": "Calculators"
},
{
    "index": 1,
    "yaml": "Parties_Inquiries.yaml",
    "description": "Allow you to fetch details like personal information, address information, contact information, party to party relationship details. They also allow you to fetch all the accounts for a specified party id.",
    "parentcategory": "Parties",
    "displayName": "Inquiries"
},
{
    "index": 2,
    "yaml": "Parties_Maintenances.yaml",
    "description": "Allow to update certain information related to a party id like address details and contact information.",
    "parentcategory": "Parties",
    "displayName": "Maintenances"
},
{
    "index": 3,
    "yaml": "Parties_PartyPreferences.yaml",
    "description": "Allow you to setup and configure party preferences like approval type and the daily business limit and user limit packages for a specified party ID.  One can also enable/disable access for the party from the channel.",
    "parentcategory": "Parties",
    "displayName": "Party Preferences"
},
{
    "index": 1,
    "yaml": "Alerts_Maintenance.yaml",
    "description": "Allows you to setup the alert templates and the content for each alert.",
    "parentcategory": "Alerts",
    "displayName": "Maintenance"
},
{
    "index": 2,
    "yaml": "Alerts_Subscriptions.yaml",
    "description": "Allows listing all the alerts for a given module. You can then enable/disable various alerts for the specified dispatch modes of email and/or mobile and/or notification for the party id.",
    "parentcategory": "Alerts",
    "displayName": "Subscriptions"
},
{
    "index": 1,
    "yaml": "Authorization_Resources.yaml",
    "description": "Allows you to configure and manage the various resources setup in the system.",
    "parentcategory": "Authorization ",
    "displayName": "Resources"
},
{
    "index": 2,
    "yaml": "Authorization_Roles.yaml",
    "description": "Allows you to configure and manage the various application roles setup in the system.",
    "parentcategory": "Authorization ",
    "displayName": "Roles"
},
{
    "index": 3,
    "yaml": "Authorization_Access Policies.yaml",
    "description": "Allows you to configure and manage the various access policies setup in the system.",
    "parentcategory": "Authorization ",
    "displayName": "Access Policies"
},
{
    "index": 4,
    "yaml": "Authorization_Entitlements.yaml",
    "description": "Allows you to configure and manage the various entitlements setup in the system.",
    "parentcategory": "Authorization ",
    "displayName": "Entitlements"
},
{
    "index": 5,
    "yaml": "Authorization_Users.yaml",
    "description": "Allows you to create, configure and manage the users in the system. APIs that enable the channel onboarding of the user. Allow you to fetch the details of the user's profile from the identity management system.",
    "parentcategory": "Authorization ",
    "displayName": "Users"
},
{
    "index": 6,
    "yaml": "Authorization_Account Access.yaml",
    "description": "Allows you to enable/disable access to CASA, TD and Loan accounts for the specified party. You can also enable/disable access to CASA, TD, Loan accounts for the specified users of the party.",
    "parentcategory": "Authorization ",
    "displayName": "Account Access"
},
{
    "index": 7,
    "yaml": "Authorization_PartyPreferences.yaml",
    "description": "Allows you to setup and configure party preferences for different modules and availablity of party for various online transactions.",
    "parentcategory": "Authorization ",
    "displayName": "Party Preferences"
},
{
    "index": 1,
    "yaml": "Limits_Inquiries.yaml",
    "description": "Allows you to inquire the various limits setup for the various transactions. You can also fetch the limit utilized for a particular user.",
    "parentcategory": "Limits ",
    "displayName": "Inquiries"
},
{
    "index": 2,
    "yaml": "Limits_Maintenances.yaml",
    "description": "Allows you to setup and manage limit groups and limits.",
    "parentcategory": "Limits ",
    "displayName": "Maintenances"
},
{
    "index": 1,
    "yaml": "Authentication_Session.yaml",
    "description": "API to create a new session for the user who wants to access the application.",
    "parentcategory": "Authentication",
    "displayName": "Session"
},
{
    "index": 1,
    "yaml": "Enumerations_Originations.yaml",
    "description": "Enumerations used for originations are available in this category",
    "parentcategory": "Enumerations",
    "displayName": "Originations"
},
{
    "index": 2,
    "yaml": "Enumerations_Global.yaml",
    "description": "Enumerations used throughout the application are available in this category.",
    "parentcategory": "Enumerations",
    "displayName": "Global"
},
{
    "index": 1,
    "yaml": "Approvals_Groups.yaml",
    "description": "Allow you setup and manage group of users who can initiate or approve a transaction.",
    "parentcategory": "Approvals",
    "displayName": "UserGroups"
},
{
    "index": 2,
    "yaml": "Approvals_Hierarchy.yaml",
    "description": "Allow you to setup and manage workflows which defines the hierarchy of approval(s) for a transaction.",
    "parentcategory": "Approvals",
    "displayName": "Workflows"
},
{
    "index": 3,
    "yaml": "Approvals_Condition.yaml",
    "description": "Allow you to setup and manage rules which define the criteria for selecting a workflow for a transaction.",
    "parentcategory": "Approvals",
    "displayName": "Rules"
},
{
    "index": 4,
    "yaml": "Approvals_Status.yaml",
    "description": "Allow you to fetch transactions which support approvals and perform actions such as approve, reject and request modification on them. One can fetch the transactions for the logged in user or all the transactions across all the users for a specified party Id.",
    "parentcategory": "Approvals",
    "displayName": "Transactions"
},
{
    "index": 1,
    "yaml": "File Upload_File Upload and View.yaml",
    "description": "Allow you to upload and view files for the various file templates mapped for the users of the party. You can also fetch the detailed records of a file based on the specified parameters, download a response file for the uploaded file that was processed.",
    "parentcategory": "File Uploads",
    "displayName": "File Upload and View"
},
{
    "index": 2,
    "yaml": "File Upload_Template Setup.yaml",
    "description": "Allow you to configure and map file upload templates to a party, map those file upload templates to the users of a party. ",
    "parentcategory": "File Uploads",
    "displayName": "Template Setup"
},
{
    "index": 1,
    "yaml": "Goals_Categories.yaml",
    "description": "Allow you to configure and manage goal categories to create goals. One can create different goals under various categories, and manage it by contributing in a systematic periodic manner. These are created so that customer can relate himself to something and try to achieve it by saving continously towards it. Each category will have a unique category code and can have expiry date too. One of the products would be mapped to it and it can support multiple unique sub categories. ",
    "parentcategory": "Goals",
    "displayName": "Goal Categories"
},
{
    "index": 2,
    "yaml": "Goals_Calculator.yaml",
    "description": "Allows you to calculate your goal. One needs to provide basic details like Goal Amount to be achieved, tenure of the goal, initial contribution and frequency, which will then fetch him the contibution amount required. The rate offered would be as of the underlying product mapped to the category of the goal chosen. ",
    "parentcategory": "Goals",
    "displayName": "Goal Calculator"
},
{
    "index": 3,
    "yaml": "Goals_Products.yaml",
    "description": "Allow you to fetch goal products. Every goal category would be linked to one underlying product, which would determine the minimum and maximum value of amount for which the goal can be created, along with minimum and maximum tenure of the same. Also it will be the deciding factor how the goal amount is being calculated. ",
    "parentcategory": "Goals",
    "displayName": "Goal Products"
},
{
    "index": 4,
    "yaml": "Goals_Account.yaml",
    "description": "Allow you to set up a facility, to attain a targeted value in a chosen tenure. An amount which is required to achieve a financial goal is set, with a timeframe for the same. Further it allows you to set the the funding account and account where the maturity value will be deposited. A set interest rate would be earned for the tenure the money is there with bank, based on the parameters and values chosen by user and as provided by bank. Account can be created under any category – sub category available. Also  instructions can be set by user to contribute some money on a systematic basis (e.g. weekly, monthly, quarterly)or ad hoc basis to facilitate timely achievement.",
    "parentcategory": "Goals",
    "displayName": "Goal Account"
},
{
    "index": 1,
    "yaml": "SpendingAnalysis_Categories.yaml",
    "description": "Allows you to differentiate various transactions based on the product or service for which it has been done. And club them together for clear cut demarcation against other groups sharing similar kind of transactions clubbed together. ",
    "parentcategory": "Spend Analysis",
    "displayName": "Spend Categories"
},
{
	"index": 2,
    "yaml": "SpendingAnalysis_CategorizedTransaction.yaml",
    "description": "Allow you to get the transactions categorized based on a set rule, based on some keywords in the description of transaction. And group all transactions falling under the same category automatically . ",
    "parentcategory": "Spend Analysis",
    "displayName": "Categorized Transaction"
},
{
    "index": 1,
    "yaml": "Budget_.yaml",
    "description": "Allow you to set a limit on various categories of spend which you can actually stick to. Over the period of time you can then observe and analyze the current status and progress of expenditures against the budgeted value. You can further set the frequency of budget, i.e. whether you want it  for current month, period of months or recurring basis. This can be created for new customized categories as well. Once created, you can adjust the budget as per your spend pattern, thus ensuring maximum savings.",
    "parentcategory": "Budget",
    "displayName": "Budget"
},
{
	"index": 1,
    "yaml": "Account Nickname_Inquiries.yaml",
    "description": "Allows you to get the list of all nicknames set for your accounts.",
    "parentcategory": "Account Nickname",
    "displayName": "Inquiries"
},
{
	"index": 2,
    "yaml": "Account Nickname_Maintenance.yaml",
    "description": "Allows you to set, update and delete nickname for your account.",
    "parentcategory": "Account Nickname",
    "displayName": "Maintenance"
},
{
	"index": 1,
    "yaml": "Working Window_Inquiries.yaml",
    "description": "Allows you to get the list of existing working windows for given transaction. Also allows you to fetch details of a specific working window.",
    "parentcategory": "Working Window",
    "displayName": "Inquiries"
},
{
	"index": 2,
    "yaml": "Working Window_Maintenance.yaml",
    "description": "Allows you to create, update and delete working window.",
    "parentcategory": "Working Window",
    "displayName": "Maintenance"
},
{
	"index": 1,
    "yaml": "Transaction Blackout_Inquiries.yaml",
    "description": "Allows you to get the list of existing blackouts maintained in the system. Also allows you to fetch details of a specific blackout.",
    "parentcategory": "Transaction Blackout",
    "displayName": "Inquiries"
},
{
	"index": 2,
    "yaml": "Transaction Blackout_Maintenance.yaml",
    "description": "Allows you to create, update and delete transaction blackout.",
    "parentcategory": "Transaction Blackout",
    "displayName": "Maintenance"
},

{
	"index": 1,
    "yaml": "Reports_Report Generation.yaml",
    "description": "Using this option, administrators can generate various adhoc banking reports. Application provides an option to generate and schedule reports using Oracle Business Intelligence (BI) Publisher and also by using an internal application. The adoption of Oracle BI Publisher provides a simple and easy tool for the Operational and MIS reports.",
    "parentcategory": "Reports",
    "displayName": "Report Generation"
	
},
{
	"index": 2,
    "yaml": "Reports_My Reports.yaml",
    "description": "Using this option, administrators can generate various adhoc banking reports. Application provides an option to generate and schedule reports using Oracle Business Intelligence (BI) Publisher and also by using an internal application. The adoption of Oracle BI Publisher provides a simple and easy tool for the Operational and MIS reports.",
    "parentcategory": "Reports",
    "displayName": "My Reports"
	
}
]}
