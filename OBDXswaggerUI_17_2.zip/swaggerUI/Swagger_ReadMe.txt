Steps to setup Swagger UI
---------------------------

1) Copy  the SwaggerUI.zip to the destination folder
2) Swagger UI needs a HTTPServer to render itself.
3) A standalone HTTP Server can be run using Python.
4) Install Python.
5) Add python intallation path to environment varible PATH (eg.C:\Users\DefaultUser\AppData\Local\Programs\Python\Python35). Please refer "Python path setting.docx" file to set environment variable.
6) Assuming the SwaggerUI is deployed on a Windows machine in the following path - D:\OBDX1702Release\swaggerUI, following command should be run to start a HTTPServer using python ( 8888 is the port for HTTP server listen)

cmd>cd D:\OBDX1702Release

PLEASE NOTE THAT SWAGGERUI is ROOT CONTEXT and should not be in the above path when HTTPServer is started.

	python -m SimpleHTTPServer 8888
	( this is for versions earlier than Python 3)
	
	OR
	
	python -m http.server 8888 
	( this is for Python 3 version)

7) Run the following command from browser : http://localhost:8888/swaggerUI/welcome.html
8) "Try it out" feature of Swagger has been disabled.
9) In case the IP address and port numbers are to be changed - changes are to be done in welcome.html file (earlier categories.js file in SwaggerUI and all the YAML files).